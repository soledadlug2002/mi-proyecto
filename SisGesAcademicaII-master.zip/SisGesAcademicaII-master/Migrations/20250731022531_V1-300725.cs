﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SisGesAcademica.Migrations
{
    /// <inheritdoc />
    public partial class V1300725 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Carreras",
                columns: table => new
                {
                    CaId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CaNombre = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CaSigla = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    CaDurAnios = table.Column<int>(type: "int", nullable: false),
                    CaTitOtorgado = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Carreras", x => x.CaId);
                });

            migrationBuilder.CreateTable(
                name: "Roles",
                columns: table => new
                {
                    RoId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoDenominacion = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Roles", x => x.RoId);
                });

            migrationBuilder.CreateTable(
                name: "Usuarios",
                columns: table => new
                {
                    UsId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UsDni = table.Column<long>(type: "bigint", nullable: false),
                    UsApellido = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    UsNombre = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    UsEmail = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    UsTelefono = table.Column<long>(type: "bigint", nullable: true),
                    UsContrasena = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    RoId = table.Column<int>(type: "int", nullable: false),
                    FechaCreacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaNacimiento = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UsActivo = table.Column<bool>(type: "bit", nullable: false),
                    token_recovery = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    date_created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UsGenero = table.Column<int>(type: "int", nullable: false),
                    Discriminator = table.Column<string>(type: "nvarchar(8)", maxLength: 8, nullable: false),
                    AlLegajo = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    CaId = table.Column<int>(type: "int", nullable: true),
                    AlIngreso = table.Column<int>(type: "int", nullable: true),
                    AlEsAcademico = table.Column<int>(type: "int", nullable: true),
                    DoLegajo = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    DoTitulo = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    DoEspecialidad = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Usuarios", x => x.UsId);
                    table.ForeignKey(
                        name: "FK_Usuarios_Carreras_CaId",
                        column: x => x.CaId,
                        principalTable: "Carreras",
                        principalColumn: "CaId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Usuarios_Roles_RoId",
                        column: x => x.RoId,
                        principalTable: "Roles",
                        principalColumn: "RoId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Materias",
                columns: table => new
                {
                    MaId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MaNombre = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    MaAnio = table.Column<int>(type: "int", nullable: false),
                    Cuatrimestre = table.Column<int>(type: "int", nullable: false),
                    DoId = table.Column<int>(type: "int", nullable: true),
                    MaCupoMaximo = table.Column<int>(type: "int", nullable: false),
                    CaId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Materias", x => x.MaId);
                    table.ForeignKey(
                        name: "FK_Materias_Carreras_CaId",
                        column: x => x.CaId,
                        principalTable: "Carreras",
                        principalColumn: "CaId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Materias_Usuarios_DoId",
                        column: x => x.DoId,
                        principalTable: "Usuarios",
                        principalColumn: "UsId",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "Inscripciones",
                columns: table => new
                {
                    InscripcionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AlId = table.Column<int>(type: "int", nullable: false),
                    MaId = table.Column<int>(type: "int", nullable: false),
                    FechaInscripcion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Estado = table.Column<int>(type: "int", nullable: false),
                    CalificacionFinal = table.Column<decimal>(type: "decimal(18,2)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Inscripciones", x => x.InscripcionId);
                    table.ForeignKey(
                        name: "FK_Inscripciones_Materias_MaId",
                        column: x => x.MaId,
                        principalTable: "Materias",
                        principalColumn: "MaId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Inscripciones_Usuarios_AlId",
                        column: x => x.AlId,
                        principalTable: "Usuarios",
                        principalColumn: "UsId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Inscripciones_AlId",
                table: "Inscripciones",
                column: "AlId");

            migrationBuilder.CreateIndex(
                name: "IX_Inscripciones_MaId",
                table: "Inscripciones",
                column: "MaId");

            migrationBuilder.CreateIndex(
                name: "IX_Materias_CaId",
                table: "Materias",
                column: "CaId");

            migrationBuilder.CreateIndex(
                name: "IX_Materias_DoId",
                table: "Materias",
                column: "DoId");

            migrationBuilder.CreateIndex(
                name: "IX_Usuarios_CaId",
                table: "Usuarios",
                column: "CaId");

            migrationBuilder.CreateIndex(
                name: "IX_Usuarios_RoId",
                table: "Usuarios",
                column: "RoId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Inscripciones");

            migrationBuilder.DropTable(
                name: "Materias");

            migrationBuilder.DropTable(
                name: "Usuarios");

            migrationBuilder.DropTable(
                name: "Carreras");

            migrationBuilder.DropTable(
                name: "Roles");
        }
    }
}
