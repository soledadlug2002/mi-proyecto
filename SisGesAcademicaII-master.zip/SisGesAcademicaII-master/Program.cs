﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using SisGesAcademica.Data;
using SisGesAcademica.Data.DTO;
var builder = WebApplication.CreateBuilder(args);

// 1. Configuración de la base de datos
builder.Services.AddDbContext<SisGesAcademicaContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("SisGesAcademicaContext") ?? throw new InvalidOperationException("Connection string 'SisGesAcademicaContext' not found.")));

// 2. Registro de servicios
builder.Services.AddScoped<UsuarioDTO>(); // Registra UsuarioDTO como servicio de ámbito

// 3. Servicios de controladores con vistas
builder.Services.AddControllersWithViews();

// 4. Configuración de autenticación
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Login/Index";
        options.LogoutPath = "/Access/Logout";
        options.ExpireTimeSpan = TimeSpan.FromMinutes(5);
        options.AccessDeniedPath = "/Home/Privacy";
    });

var app = builder.Build();

// 5. Configuración de la canalización de solicitudes HTTP
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

// 6. Redirección HTTPS solo en producción
if (app.Environment.IsProduction())
{
    app.UseHttpsRedirection();
}

// 7. Archivos estáticos
app.UseStaticFiles();

// 8. Rutas
app.UseRouting();

// 9. Autenticación y autorización
app.UseAuthentication();
app.UseAuthorization();

// 10. Configuración de las rutas de los controladores
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");


// 11. Ejecución de la aplicación
app.Run();