﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SisGesAcademica.Models
{
    public class Inscripcion
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int InscripcionId { get; set; }

        [Required]
        [ForeignKey("Alumno")]
        public int AlId { get; set; }
        public virtual Alumno? Alumno { get; set; }

        [Required]
        [ForeignKey("Materia")]
        public int MaId { get; set; }
        public virtual Materia? Materia { get; set; }


        [Required]
        public DateTime FechaInscripcion { get; set; } = DateTime.Now;

        [Required]
        public EstadoInscripcion Estado { get; set; } = EstadoInscripcion.Inscripto;

        [Display(Name = "Calificación")]
        [Range(0, 10, ErrorMessage = "La calificación debe estar entre 0 y 10.")]
        public decimal? CalificacionFinal { get; set; }



        public enum EstadoInscripcion
        {
            Inscripto,
            Cursando,
            Aprobado,
            Desaprobado,
            Libre
        }
    }
}
