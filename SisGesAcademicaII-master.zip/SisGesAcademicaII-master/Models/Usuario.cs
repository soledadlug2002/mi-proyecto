﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SisGesAcademica.Models
{
    public partial class Usuario
    {
        [Key]
        public int UsId { get; set; }


        [RegularExpression(@"^[1-9][0-9]*$", ErrorMessage = "Sólo se permiten números de DNI válidos.")]
        [Display(Name = "DNI")]
        [Range(6000000, 99999999, ErrorMessage = "Debe ingresar los 7-8 dígitos del DNI.")]
        [Required(ErrorMessage = "Debe ingresar un número de DNI válido (8 dígitos).")]
        public long UsDni { get; set; }


        [RegularExpression(@"^[A-Za-záéíóúÁÉÍÓÚüÜñÑ\s]*$", ErrorMessage = "Ingrese un apellido válido.")]
        [Display(Name = "Apellido")]
        [MaxLength(50, ErrorMessage = "No se permiten más de 50 caracteres.")]
        [Required(ErrorMessage = "Debe ingresar un Apellido")]
        public string UsApellido { get; set; } = null!;


        [RegularExpression(@"^[A-Za-záéíóúÁÉÍÓÚüÜñÑ\s]*$", ErrorMessage = "Ingrese un nombre válido.")]
        [Display(Name = "Nombres")]
        [MaxLength(50, ErrorMessage = "No se permiten más de 50 caracteres.")]
        [Required(ErrorMessage = "Debe ingresar un Nombre.")]
        public string UsNombre { get; set; } = null!;


        [Display(Name = "Email")]
        [EmailAddress(ErrorMessage = "Por favor verifique su dirección de email.")]
        [MaxLength(50, ErrorMessage = "No se permiten más de 50 caracteres.")]
        public string? UsEmail { get; set; }


        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Ingrese un número telefónico válido de 10 dígitos.")]
        [Display(Name = "Teléfono")]
        [Range(1000000000, 9999999999, ErrorMessage = "Ingrese un número telefónico válido sin espacios ni guiones y sin 0 ni 15.")]
        public long? UsTelefono { get; set; }


        [Display(Name = "Contraseña")]
        [PasswordPropertyText(true)]
        [Required(ErrorMessage = "Debe ingresar una contraseña.")]
        [MinLength(8, ErrorMessage = "No se permiten menos de 8 caracteres.")]
        [MaxLength(50, ErrorMessage = "No se permiten más de 50 caracteres.")]
        public string UsContrasena { get; set; } = null!;


        [Display(Name = "Rol")]
        [Required(ErrorMessage = "Debe elegir un rol.")]
        public int RoId { get; set; }
        public virtual Role? Ro { get; set; } = null!;


        public DateTime FechaCreacion { get; set; } = DateTime.Now;


        [Required(ErrorMessage = "La fecha de nacimiento es obligatoria")]
        [Display(Name = "Fecha de Nacimiento")]
        [DataType(DataType.Date)]
        public DateTime FechaNacimiento { get; set; }


        [Display(Name = "Activo")]
        public bool UsActivo { get; set; }


        public string? token_recovery { get; set; } = "tokenbloqueado";


        public DateTime date_created { get; set; } = DateTime.Now;


        [Required]
        public Genero UsGenero { get; set; }



        public enum Genero
        {
            Masculino,
            Femenino,
            Otro
        }


        [NotMapped]
        public string FullName => $"{UsNombre} {UsApellido}";



        //public virtual ICollection<Alumno> Alumnos { get; set; } = new List<Alumno>();

        //public virtual ICollection<Docente> Profesores { get; set; } = new List<Docente>();
    }
}
