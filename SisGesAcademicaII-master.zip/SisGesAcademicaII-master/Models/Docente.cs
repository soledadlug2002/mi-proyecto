﻿using System.ComponentModel.DataAnnotations;

namespace SisGesAcademica.Models
{

    public class Docente : Usuario
    {

        [Display(Name = "Legajo")]
        [Required(ErrorMessage = "El legajo es obligatorio.")]
        public string DoLegajo { get; set; } = null!;

        [Display(Name = "Título")]
        [Required(ErrorMessage = "El título es obligatorio.")]
        [StringLength(100, ErrorMessage = "El título no puede exceder {1} caracteres.")]
        public string DoTitulo { get; set; } = null!; // Cambiado a no nullable

        [Display(Name = "Especialidad")]
        [StringLength(100, ErrorMessage = "La especialidad no puede exceder {1} caracteres.")]
        public string? DoEspecialidad { get; set; }

        // Relaciones
        public virtual ICollection<Materia> Materias { get; set; } = new List<Materia>();




    }
}
