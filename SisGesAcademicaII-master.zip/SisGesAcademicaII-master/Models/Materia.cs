﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SisGesAcademica.Models
{
    public class Materia
    {
        [Key]
        public int MaId { get; set; }

        [Required(ErrorMessage = "El nombre de la materia es obligatorio.")]
        [MaxLength(100, ErrorMessage = "El nombre no puede tener más de 100 caracteres.")]
        [Display(Name = "Nombre de la Materia")]
        public string MaNombre { get; set; } = null!;

        [Required(ErrorMessage = "El año es obligatorio.")]
        [Range(1, 6, ErrorMessage = "El año debe estar entre 1 y 6.")]
        [Display(Name = "Año")]
        public int MaAnio { get; set; }

        [Required(ErrorMessage = "Debe seleccionar un cuatrimestre.")]
        [Display(Name = "Cuatrimestre")]
        public Cuatrimestre Cuatrimestre { get; set; }

        [ForeignKey("Docente")] // Añadir esto
        public int? DoId { get; set; }

        public virtual Docente? Docente { get; set; }

        [Required(ErrorMessage = "El cupo máximo es obligatorio.")]
        [Range(1, 1000, ErrorMessage = "El cupo debe estar entre 1 y 1000.")]
        [Display(Name = "Cupo Máximo")]
        public int MaCupoMaximo { get; set; }

        public virtual ICollection<Inscripcion> Inscripciones { get; set; } = new List<Inscripcion>();


        [Display(Name = "Carrera")]
        [Required(ErrorMessage = "Debe seleccionar una carrera.")]
        public int CaId { get; set; }

        [ForeignKey("CaId")]
        public virtual Carrera? Carrera { get; set; }

    }

    public enum Cuatrimestre
    {
        [Display(Name = "Primero")]
        Primero = 1,

        [Display(Name = "Segundo")]
        Segundo = 2
    }
}
