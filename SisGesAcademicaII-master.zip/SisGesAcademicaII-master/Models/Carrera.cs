﻿using System.ComponentModel.DataAnnotations;

namespace SisGesAcademica.Models
{
    public class Carrera
    {
        [Key]
        public int CaId { get; set; }

        [Required(ErrorMessage = "El nombre de la carrera es obligatorio.")]
        [MaxLength(100, ErrorMessage = "El nombre no puede tener más de 100 caracteres.")]
        [Display(Name = "Nombre de la Carrera")]
        public string CaNombre { get; set; } = null!;

        [Required(ErrorMessage = "La sigla es obligatoria.")]
        [MaxLength(10, ErrorMessage = "La sigla no puede tener más de 10 caracteres.")]
        [RegularExpression(@"^[A-Z0-9]+$", ErrorMessage = "La sigla solo puede contener letras mayúsculas y números (ej: TECAS).")]
        [Display(Name = "Sigla")]
        public string CaSigla { get; set; } = null!;

        [Required(ErrorMessage = "La duración es obligatoria.")]
        [Range(1, 10, ErrorMessage = "La duración debe estar entre 1 y 10 años.")]
        [Display(Name = "Duración (años)")]
        public int CaDurAnios { get; set; }

        [Required(ErrorMessage = "El título otorgado es obligatorio.")]
        [MaxLength(150, ErrorMessage = "El título no puede tener más de 150 caracteres.")]
        [Display(Name = "Título Otorgado")]
        public string CaTitOtorgado { get; set; } = null!;

        public virtual ICollection<Alumno> Alumnos { get; set; } = new List<Alumno>();

        public virtual ICollection<Materia> Materias { get; set; } = new List<Materia>();

    }
}
