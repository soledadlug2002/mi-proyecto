﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SisGesAcademica.Models
{
    public class Alumno : Usuario
    {

        [Display(Name = "Legajo")]
        [MaxLength(20)]
        public string? AlLegajo { get; set; }

        [ForeignKey("Carrera")]
        public int? CaId { get; set; }
        public virtual Carrera? Carrera { get; set; }

        [Display(Name = "Año de Ingreso")]
        [Required(ErrorMessage = "Debe ingresar el año de ingreso.")]
        public int? AlIngreso { get; set; }

        [Display(Name = "Estado Académico")]
        public EstadoAcademico AlEsAcademico { get; set; } = EstadoAcademico.Activo;

        public virtual ICollection<Inscripcion> Inscripciones { get; set; } = new List<Inscripcion>();


        public enum EstadoAcademico
        {
            Activo,
            Graduado,
            Suspendido,
            Retirado
        }

    }
}
