﻿using System.ComponentModel.DataAnnotations;

namespace SisGesAcademica.Models
{
    public partial class Role
    {
        [Key]
        public int RoId { get; set; }

        [RegularExpression(@"^[A-Za-záéíóúÁÉÍÓÚüÜñÑ\s]*$", ErrorMessage = "Solo se permiten letras.")]
        [Display(Name = "Rol")]
        [MaxLength(50, ErrorMessage = "No se permiten más de 50 caracteres.")]
        [Required(ErrorMessage = "Debe ingresar un Rol")]
        public string RoDenominacion { get; set; } = null!;

        public virtual ICollection<Usuario> Usuarios { get; set; } = new List<Usuario>();
    }
}
