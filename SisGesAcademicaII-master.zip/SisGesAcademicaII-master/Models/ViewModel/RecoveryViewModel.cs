﻿using System.ComponentModel.DataAnnotations;

namespace SisGesAcademica.Models.ViewModel
{
    public class RecoveryViewModel
    {
        [Required(ErrorMessage = "El email es obligatorio para recuperación")]
        [EmailAddress(ErrorMessage = "Formato de email inválido")]
        [MaxLength(50, ErrorMessage = "Máximo 50 caracteres")]
        public string UsEmail { get; set; } = null!;
    }
}
