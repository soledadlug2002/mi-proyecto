﻿using SisGesAcademica.Data.DTO;

namespace SisGesAcademica.Models.ViewModel
{
    public class AsociarAlumnosViewModel
    {
        public int MaId { get; set; }
        public string MaNombre { get; set; } = null!;
        public string CarreraNombre { get; set; } = null!;
        public List<AlumnoSeleccionable> Alumnos { get; set; } = new List<AlumnoSeleccionable>();
        public List<int> AlumnosSeleccionados { get; set; } = new List<int>();
    }

}
