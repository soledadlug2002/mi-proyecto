﻿using System.ComponentModel.DataAnnotations;

namespace SisGesAcademica.Models.ViewModel
{
    public class RecoveryPasswordViewModel
    {
        [Required(ErrorMessage = "Token inválido")]
        public string token { get; set; } = null!;

        [Required(ErrorMessage = "La nueva contraseña es obligatoria")]
        [StringLength(50, MinimumLength = 8, ErrorMessage = "Mínimo 8 caracteres")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,}$",
            ErrorMessage = "Debe incluir mayúsculas, minúsculas, números y símbolos")]
        [DataType(DataType.Password)]
        public string UsContrasena { get; set; } = null!;

        [Required(ErrorMessage = "Confirme la contraseña")]
        [DataType(DataType.Password)]
        [Compare("UsContrasena", ErrorMessage = "Las contraseñas no coinciden")]
        public string UsContrasena2 { get; set; } = null!;
    }
}
