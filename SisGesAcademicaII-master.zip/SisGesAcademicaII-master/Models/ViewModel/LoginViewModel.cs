﻿using System.ComponentModel.DataAnnotations;

namespace SisGesAcademica.Models.ViewModel
{
    public class LoginViewModel
    {
        [Display(Name = "DNI")]
        [Required(ErrorMessage = "Debe ingresar su DNI.")]
        [RegularExpression(@"^[1-9][0-9]*$", ErrorMessage = "Sólo se permiten números de DNI válidos.")]
        [Range(6000000, 99999999, ErrorMessage = "Debe ingresar un DNI válido (entre 7 y 8 dígitos).")]
        public long Dni { get; set; }

        [Display(Name = "Contraseña")]
        [DataType(DataType.Password)]
        [Required(ErrorMessage = "Debe ingresar su contraseña.")]
        public string Clave { get; set; }
    }
}
