﻿using System.ComponentModel.DataAnnotations;

namespace SisGesAcademica.Models.ViewModel
{
    public class RegistroViewModel
    {
        // Datos personales
        [Display(Name = "DNI")]
        [Required(ErrorMessage = "El DNI es obligatorio")]
        [RegularExpression(@"^[1-9][0-9]*$", ErrorMessage = "Solo números válidos")]
        [Range(6000000, 99999999, ErrorMessage = "DNI debe tener entre 7 y 8 dígitos")]
        public long UsDni { get; set; }

        [Display(Name = "Apellido")]
        [Required(ErrorMessage = "El apellido es obligatorio")]
        [RegularExpression(@"^[A-Za-záéíóúÁÉÍÓÚüÜñÑ\s]*$", ErrorMessage = "Solo letras y espacios")]
        [MaxLength(50, ErrorMessage = "Máximo 50 caracteres")]
        public string UsApellido { get; set; } = null!;

        [Display(Name = "Nombres")]
        [Required(ErrorMessage = "El nombre es obligatorio")]
        [RegularExpression(@"^[A-Za-záéíóúÁÉÍÓÚüÜñÑ\s]*$", ErrorMessage = "Solo letras y espacios")]
        [MaxLength(50, ErrorMessage = "Máximo 50 caracteres")]
        public string UsNombre { get; set; } = null!;

        [Display(Name = "Email")]
        [Required(ErrorMessage = "El email es obligatorio")]
        [EmailAddress(ErrorMessage = "Formato de email inválido")]
        [MaxLength(50, ErrorMessage = "Máximo 50 caracteres")]
        public string UsEmail { get; set; } = null!;

        [Display(Name = "Teléfono (opcional)")]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "10 dígitos sin espacios")]
        public long? UsTelefono { get; set; }

        // Credenciales
        [Display(Name = "Contraseña")]
        [Required(ErrorMessage = "La contraseña es obligatoria")]
        [DataType(DataType.Password)]
        [MinLength(8, ErrorMessage = "Mínimo 8 caracteres")]
        [MaxLength(50, ErrorMessage = "Máximo 50 caracteres")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,}$",
            ErrorMessage = "Debe incluir minúscula, mayúscula, número y símbolo")]
        public string UsContrasena { get; set; } = null!;

        [Display(Name = "Confirmar Contraseña")]
        [Required(ErrorMessage = "Confirme la contraseña")]
        [DataType(DataType.Password)]
        [Compare("UsContrasena", ErrorMessage = "Las contraseñas no coinciden")]
        public string ConfirmarContrasena { get; set; } = null!;

        // Información adicional
        [Display(Name = "Fecha de Nacimiento")]
        [Required(ErrorMessage = "La fecha de nacimiento es obligatoria")]
        [DataType(DataType.Date)]
        [AgeValidation(MinAge = 16, MaxAge = 100,
            ErrorMessage = "Debe tener entre 16 y 100 años")]
        public DateTime FechaNacimiento { get; set; } = DateTime.Now.AddYears(-18);

        [Display(Name = "Género")]
        [Required(ErrorMessage = "Seleccione un género")]
        public Genero UsGenero { get; set; }

        [Display(Name = "Tipo de Usuario")]
        [Required(ErrorMessage = "Seleccione un tipo de usuario")]
        public TipoUsuario TipoRegistro { get; set; }

        // Campos específicos para Alumnos
        [Display(Name = "Legajo (Alumno)")]
        [MaxLength(20, ErrorMessage = "Máximo 20 caracteres")]
        [RequiredIf(nameof(TipoRegistro), TipoUsuario.Alumno,
            ErrorMessage = "El legajo es obligatorio para alumnos")]
        public string? AlLegajo { get; set; }

        [Display(Name = "Carrera")]
        [RequiredIf(nameof(TipoRegistro), TipoUsuario.Alumno,
            ErrorMessage = "Seleccione una carrera")]
        public int? CaId { get; set; }

        [Display(Name = "Año de Ingreso")]
        [Range(2000, 2100, ErrorMessage = "Año inválido")]
        [RequiredIf(nameof(TipoRegistro), TipoUsuario.Alumno,
            ErrorMessage = "El año de ingreso es obligatorio")]
        public int? AlIngreso { get; set; }

        // Campos específicos para Docentes
        [Display(Name = "Legajo (Docente)")]
        [MaxLength(20, ErrorMessage = "Máximo 20 caracteres")]
        [RequiredIf(nameof(TipoRegistro), TipoUsuario.Docente,
            ErrorMessage = "El legajo es obligatorio para docentes")]
        public string? DoLegajo { get; set; }

        [Display(Name = "Título (opcional)")]
        [MaxLength(100, ErrorMessage = "Máximo 100 caracteres")]
        public string? DoTitulo { get; set; }

        [Display(Name = "Especialidad (opcional)")]
        [MaxLength(100, ErrorMessage = "Máximo 100 caracteres")]
        public string? DoEspecialidad { get; set; }
    }

    // Enums
    public enum Genero
    {
        Masculino,
        Femenino,
        Otro
    }

    public enum TipoUsuario
    {
        Alumno,
        Docente
    }

    // Validación personalizada para edad
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class AgeValidationAttribute : ValidationAttribute
    {
        public int MinAge { get; set; }
        public int MaxAge { get; set; }

        public override bool IsValid(object? value)
        {
            if (value is DateTime fechaNacimiento)
            {
                var edad = DateTime.Today.Year - fechaNacimiento.Year;
                if (fechaNacimiento.Date > DateTime.Today.AddYears(-edad)) edad--;

                return edad >= MinAge && edad <= MaxAge;
            }
            return false;
        }
    }

    // Validación condicional
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class RequiredIfAttribute : ValidationAttribute
    {
        public string PropertyName { get; set; }
        public object ExpectedValue { get; set; }

        public RequiredIfAttribute(string propertyName, object expectedValue)
        {
            PropertyName = propertyName;
            ExpectedValue = expectedValue;
        }

        protected override ValidationResult? IsValid(object? value, ValidationContext context)
        {
            var instance = context.ObjectInstance;
            var property = instance.GetType().GetProperty(PropertyName);

            if (property != null)
            {
                var propertyValue = property.GetValue(instance);

                if (propertyValue != null && propertyValue.Equals(ExpectedValue))
                {
                    if (value == null || (value is string str && string.IsNullOrWhiteSpace(str)))
                    {
                        return new ValidationResult(ErrorMessage);
                    }
                }
            }
            return ValidationResult.Success;
        }
    }
}