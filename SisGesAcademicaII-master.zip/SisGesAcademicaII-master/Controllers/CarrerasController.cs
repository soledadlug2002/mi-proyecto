﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SisGesAcademica.Data;
using SisGesAcademica.Models;

namespace SisGesAcademica.Controllers
{
    //[Authorize(Roles = "Admin, Preceptor")]
    public class CarrerasController : Controller
    {
        private readonly SisGesAcademicaContext _context;

        private readonly ILogger<CarrerasController> _logger;

        public CarrerasController(SisGesAcademicaContext context, ILogger<CarrerasController> logger)
        {
            _context = context;
            _logger = logger;
        }


        // GET: Carreras
        public async Task<IActionResult> Index()
        {
            return View(await _context.Carreras.ToListAsync());
        }


        // GET: Carreras/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carrera = await _context.Carreras
                .FirstOrDefaultAsync(m => m.CaId == id);
            if (carrera == null)
            {
                return NotFound();
            }

            return View(carrera);
        }


        // GET: Carreras/Create
        public IActionResult Create()
        {
            return View();
        }

     
        // POST: Carreras/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        // POST: Carreras/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CaId,CaNombre,CaSigla,CaDurAnios,CaTitOtorgado")] Carrera carrera)
        {
            // Validar campos requeridos primero
            if (string.IsNullOrWhiteSpace(carrera.CaNombre))
            {
                ModelState.AddModelError("CaNombre", "El nombre es requerido.");
            }

            if (string.IsNullOrWhiteSpace(carrera.CaTitOtorgado))
            {
                ModelState.AddModelError("CaTitOtorgado", "El título otorgado es requerido.");
            }

            // Solo continuar con validaciones si los campos requeridos tienen valor
            if (ModelState.IsValid)
            {
                // Preparar valores normalizados para comparación
                var nombreNormalizado = carrera.CaNombre.Trim().ToUpper();
                var tituloNormalizado = carrera.CaTitOtorgado.Trim().ToUpper();

                // Validar existencia usando los valores normalizados
                bool nombreExiste = await _context.Carreras
                    .AnyAsync(c => c.CaNombre.ToUpper() == nombreNormalizado);

                bool tituloExiste = await _context.Carreras
                    .AnyAsync(c => c.CaTitOtorgado.ToUpper() == tituloNormalizado);

                if (nombreExiste)
                {
                    ModelState.AddModelError("CaNombre", "Ya existe una carrera con este nombre.");
                }

                if (tituloExiste)
                {
                    ModelState.AddModelError("CaTitOtorgado", "Ya existe una carrera con este título otorgado.");
                }

                // Si todo es válido, proceder a guardar
                if (ModelState.IsValid)
                {
                    try
                    {
                        // Aplicar solo Trim() para guardar el formato original
                        carrera.CaNombre = carrera.CaNombre.Trim();
                        carrera.CaTitOtorgado = carrera.CaTitOtorgado.Trim();
                        carrera.CaSigla = carrera.CaSigla?.Trim(); // Sigla puede ser opcional

                        _context.Add(carrera);
                        await _context.SaveChangesAsync();

                        TempData["SuccessMessage"] = $"La carrera {carrera.CaNombre} se creó correctamente";
                        return RedirectToAction(nameof(Index));
                    }
                    catch (DbUpdateException ex)
                    {
                        _logger.LogError(ex, "Error al crear carrera");
                        ModelState.AddModelError("", "No se pudo guardar la carrera. Intente nuevamente.");

                    }
                }
            }

            return View(carrera);
        }


        // GET: Carreras/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carrera = await _context.Carreras.FindAsync(id);
            if (carrera == null)
            {
                return NotFound();
            }
            return View(carrera);
        }


        // POST: Carreras/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CaId,CaNombre,CaSigla,CaDurAnios,CaTitOtorgado")] Carrera carrera)
        {
            if (id != carrera.CaId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(carrera);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CarreraExists(carrera.CaId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(carrera);
        }



        // GET: Carreras/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var carrera = await _context.Carreras
                .FirstOrDefaultAsync(m => m.CaId == id);
            if (carrera == null)
            {
                return NotFound();
            }

            return View(carrera);
        }


        // POST: Carreras/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var carrera = await _context.Carreras.FindAsync(id);
            if (carrera != null)
            {
                _context.Carreras.Remove(carrera);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }



        private bool CarreraExists(int id)
        {
            return _context.Carreras.Any(e => e.CaId == id);
        }
    }
}
