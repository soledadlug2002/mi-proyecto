﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SisGesAcademica.Data;
using SisGesAcademica.Models;
using System.Security.Cryptography;
using System.Text;

namespace SisGesAcademica.Controllers
{

    //[Authorize(Roles = "Admin, Preceptor")]
    public class UsuariosController : Controller
    {
        private readonly SisGesAcademicaContext _context;

        public UsuariosController(SisGesAcademicaContext context)
        {
            _context = context;
        }

        // GET: Usuarios
        public async Task<IActionResult> Index()
        {
            var sisGesAcademicaContext = _context.Usuarios.Include(u => u.Ro);
            return View(await sisGesAcademicaContext.ToListAsync());
        }

        // GET: Usuarios/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var usuario = await _context.Usuarios
                .Include(u => u.Ro)
                .FirstOrDefaultAsync(m => m.UsId == id);
            if (usuario == null)
            {
                return NotFound();
            }

            return View(usuario);
        }

        // GET: Usuarios/Create
        public IActionResult Create()
        {
            ViewData["RoId"] = new SelectList(_context.Roles, "RoId", "RoDenominacion");
            ViewData["UsGenero"] = new SelectList(new List<string> { "Masculino", "Femenino" });
            return View();
        }

      

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("UsId,UsDni,UsApellido,UsNombre,UsEmail,UsTelefono,UsContrasena,RoId,FechaCreacion,FechaNacimiento,UsActivo,token_recovery,date_created,UsGenero")] Usuario usuario)
        {
            bool dniExistente = await _context.Usuarios.AnyAsync(u => u.UsDni == usuario.UsDni);

            if (dniExistente)
            {
                ModelState.AddModelError("UsDni", "El DNI ingresado ya está registrado en el sistema.");
            }

            if (ModelState.IsValid)
            {
                // Encriptar contraseña
                usuario.UsContrasena = GetMD5(usuario.UsContrasena);

                // Fecha de creación
                usuario.FechaCreacion = DateTime.Now;

                //// Obtener nombre del rol para establecer Discriminator
                var rol = await _context.Roles.FirstOrDefaultAsync(r => r.RoId == usuario.RoId);
                if (rol != null)
                {
                    //usuario.Discriminator = rol.RoDenominacion;

                    // Solo crear registro específico para roles especiales
                    if (rol.RoDenominacion == "Alumno")
                    {
               
                        // Crear alumno y guardar en lugar de usuario
                        var alumno = new Alumno
                        {

                            // Copiar propiedades del usuario
                            UsDni = usuario.UsDni,
                            UsApellido = usuario.UsApellido,
                            UsNombre = usuario.UsNombre,
                            UsEmail = usuario.UsEmail,
                            UsTelefono = usuario.UsTelefono,
                            UsContrasena = usuario.UsContrasena,
                            RoId = usuario.RoId,
                            FechaCreacion = usuario.FechaCreacion,
                            FechaNacimiento = usuario.FechaNacimiento,
                            UsActivo = usuario.UsActivo,
                            UsGenero = usuario.UsGenero,
             



                            // Propiedades específicas de alumno
                            AlLegajo = GenerarLegajoAlumno(),
                            CaId = 1, // ID de carrera por defecto
                            AlIngreso = DateTime.Now.Year,
                            AlEsAcademico = Alumno.EstadoAcademico.Activo,


                        };

                        //_context.Alumnos.Add(alumno);
                        _context.Entry(alumno).State = EntityState.Added;

                        await _context.SaveChangesAsync();
                    }
                    else if (rol.RoDenominacion == "Docente")
                    {

                        // Crear docente y guardar en lugar de usuario
                        var docente = new Docente
                        {
                            // Copiar propiedades del usuario
                            UsDni = usuario.UsDni,
                            UsApellido = usuario.UsApellido,
                            UsNombre = usuario.UsNombre,
                            UsEmail = usuario.UsEmail,
                            UsTelefono = usuario.UsTelefono,
                            UsContrasena = usuario.UsContrasena,
                            RoId = usuario.RoId,
                            FechaCreacion = usuario.FechaCreacion,
                            FechaNacimiento = usuario.FechaNacimiento,
                            UsActivo = usuario.UsActivo,
                            UsGenero = usuario.UsGenero,
             

                            // Propiedades específicas de docente
                            DoLegajo = GenerarLegajoDocente(),
                            DoTitulo = "Título por definir",
                            DoEspecialidad = "Especialidad por definir",

                        };


                        //_context.Docentes.Add(docente);
                        _context.Entry(docente).State = EntityState.Added;

                        await _context.SaveChangesAsync();
                    }
                    else
                    {
                        // Para otros roles, guardar como usuario normal
                        _context.Usuarios.Add(usuario);
                        await _context.SaveChangesAsync();
                    }

                    TempData["SuccessMessage"] = "Usuario creado exitosamente";
                    return RedirectToAction(nameof(Index));
                }
            }

            ViewData["RoId"] = new SelectList(_context.Roles, "RoId", "RoDenominacion", usuario.RoId);
            ViewData["UsGenero"] = new SelectList(new List<string> { "Masculino", "Femenino" }, usuario.UsGenero);

            return View(usuario);
        }



        private string GenerarLegajoAlumno()
        {
            int añoActual = DateTime.Now.Year;
            string nuevoLegajo;
            bool legajoExistente;
            int intentos = 0;
            const int maxIntentos = 5;

            do
            {
                var ultimoLegajo = _context.Alumnos
                    .Where(a => a.AlLegajo.StartsWith(añoActual.ToString()))
                    .OrderByDescending(a => a.AlLegajo)
                    .FirstOrDefault();

                int siguienteNumero = 1;
                if (ultimoLegajo != null)
                {
                    var partes = ultimoLegajo.AlLegajo.Split('-');
                    if (partes.Length == 2 && int.TryParse(partes[1], out int ultimoNumero))
                    {
                        siguienteNumero = ultimoNumero + 1;
                    }
                }

                nuevoLegajo = $"{añoActual}-{siguienteNumero:0000}";
                legajoExistente = _context.Alumnos.Any(a => a.AlLegajo == nuevoLegajo);
                intentos++;
            }
            while (legajoExistente && intentos < maxIntentos);

            if (legajoExistente)
            {
                throw new InvalidOperationException("No se pudo generar un legajo único después de varios intentos");
            }

            return nuevoLegajo;
        }

        private string GenerarLegajoDocente()
        {
            int añoActual = DateTime.Now.Year;
            string nuevoLegajo;
            bool legajoExistente;
            int intentos = 0;
            const int maxIntentos = 5;

            do
            {
                var ultimoLegajo = _context.Docentes
                    .Where(a => a.DoLegajo.StartsWith(añoActual.ToString()))
                    .OrderByDescending(a => a.DoLegajo)
                    .FirstOrDefault();

                int siguienteNumero = 1;
                if (ultimoLegajo != null)
                {
                    var partes = ultimoLegajo.DoLegajo.Split('-');
                    if (partes.Length == 2 && int.TryParse(partes[1], out int ultimoNumero))
                    {
                        siguienteNumero = ultimoNumero + 1;
                    }
                }

                nuevoLegajo = $"{añoActual}-{siguienteNumero:0000}";
                legajoExistente = _context.Docentes.Any(a => a.DoLegajo == nuevoLegajo);
                intentos++;
            }
            while (legajoExistente && intentos < maxIntentos);

            if (legajoExistente)
            {
                throw new InvalidOperationException("No se pudo generar un legajo único después de varios intentos");
            }

            return nuevoLegajo;
        }

        // GET: Usuarios/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var usuario = await _context.Usuarios.FindAsync(id);
            if (usuario == null)
            {
                return NotFound();
            }
            ViewData["RoId"] = new SelectList(_context.Roles, "RoId", "RoDenominacion", usuario.RoId);
            ViewData["UsGenero"] = new SelectList(new List<string> { "Masculino", "Femenino" });
            return View(usuario);
        }

        // POST: Usuarios/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("UsId,UsDni,UsApellido,UsNombre,UsEmail,UsTelefono,UsContrasena,RoId,FechaCreacion,FechaNacimiento,UsActivo,token_recovery,date_created,UsGenero")] Usuario usuario)
        {
            if (id != usuario.UsId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {

                // Encriptar contraseña
                usuario.UsContrasena = GetMD5(usuario.UsContrasena);
                try
                {

                    _context.Update(usuario);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UsuarioExists(usuario.UsId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }



                return RedirectToAction(nameof(Index));
            }
            ViewData["RoId"] = new SelectList(_context.Roles, "RoId", "RoDenominacion", usuario.RoId);
            ViewData["UsGenero"] = new SelectList(new List<string> { "Masculino", "Femenino" }, usuario.UsGenero);
            return View(usuario);
        }

        // GET: Usuarios/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var usuario = await _context.Usuarios
                .Include(u => u.Ro)
                .FirstOrDefaultAsync(m => m.UsId == id);
            if (usuario == null)
            {
                return NotFound();
            }

            return View(usuario);
        }

        // POST: Usuarios/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var usuario = await _context.Usuarios.FindAsync(id);
            if (usuario != null)
            {
                _context.Usuarios.Remove(usuario);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool UsuarioExists(int id)
        {
            return _context.Usuarios.Any(e => e.UsId == id);
        }

        private string GetMD5(string str)
        {
            MD5 md5 = MD5.Create();
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[]? stream = null;
            StringBuilder sb = new StringBuilder();
            stream = md5.ComputeHash(encoding.GetBytes(str));
            for (int i = 0; i < stream.Length; i++) sb.AppendFormat("{0:x2}", stream[i]);
            return sb.ToString();
        }





    }
}
