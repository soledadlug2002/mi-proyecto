﻿using Microsoft.AspNetCore.Mvc;
using SisGesAcademica.Data.DTO;
using System.Security.Claims;

namespace SisGesAcademica.Controllers
{
    public class InicioController : Controller
    {
        //[Authorize(Roles = "Super Admin, Admin,Usuario")]
        public IActionResult Index()
        {
            var dniClaim = User.FindFirstValue("DNI");
            var nombreClaim = User.FindFirstValue("Nombre");
            var apellidoClaim = User.FindFirstValue("Apellido");
            var emailClaim = User.FindFirstValue("Email");
            var rolClaim = User.FindFirstValue(ClaimTypes.Role);
            var bag = new UsuarioDTO { UsDni = Int32.Parse(dniClaim), UsNombre = nombreClaim, UsApellido = apellidoClaim, UsEmail = emailClaim, rol = rolClaim };
            return View(bag);
        }
    }
}
