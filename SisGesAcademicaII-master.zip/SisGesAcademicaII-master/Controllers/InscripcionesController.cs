﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SisGesAcademica.Data;
using SisGesAcademica.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SisGesAcademica.Controllers
{
    // InscripcionesController.cs
    public class InscripcionesController : Controller
    {
        private readonly SisGesAcademicaContext _context;

        public InscripcionesController(SisGesAcademicaContext context)
        {
            _context = context;
        }




        //[Authorize(Roles = "Admin, Preceptor")]
        // GET: Inscripciones
        public async Task<IActionResult> Index()
        {
            var inscripciones = await _context.Inscripciones
                .Include(i => i.Alumno)
                .Include(i => i.Materia)
                .ThenInclude(m => m.Carrera)
                .ToListAsync();
            return View(inscripciones);
        }


        //[Authorize(Roles = "Admin, Preceptor, Alumnos")]
        // GET: Inscripciones/Create
        public IActionResult Create()
        {
            ViewData["Alumnos"] = new SelectList(_context.Alumnos, "UsId", "FullName");
            ViewData["Materias"] = new SelectList(_context.Materias, "MaId", "MaNombre");
            return View();
        }

        //[Authorize(Roles = "Admin, Preceptor, Alumnos")]
        // POST: Inscripciones/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AlId,MaId,Estado,CalificacionFinal")] Inscripcion inscripcion)
        {
            inscripcion.FechaInscripcion = DateTime.Now;

            if (ModelState.IsValid)
            {
                _context.Add(inscripcion);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewData["Alumnos"] = new SelectList(_context.Alumnos, "UsId", "FullName", inscripcion.AlId);
            ViewData["Materias"] = new SelectList(_context.Materias, "MaId", "MaNombre", inscripcion.MaId);
            return View(inscripcion);
        }



        //[Authorize(Roles = "Admin, Preceptor")]
        // GET: Inscripciones/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var inscripcion = await _context.Inscripciones.FindAsync(id);
            if (inscripcion == null) return NotFound();

            return View(inscripcion);
        }


        //[Authorize(Roles = "Admin, Preceptor")]
        // POST: Inscripciones/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("InscripcionId,Estado,CalificacionFinal")] Inscripcion inscripcion)
        {
            if (id != inscripcion.InscripcionId) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    var existing = await _context.Inscripciones.FindAsync(id);
                    existing.Estado = inscripcion.Estado;
                    existing.CalificacionFinal = inscripcion.CalificacionFinal;

                    _context.Update(existing);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!InscripcionExists(inscripcion.InscripcionId))
                        return NotFound();
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(inscripcion);
        }


        //[Authorize(Roles = "Admin, Preceptor")]
        // GET: Inscripciones/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var inscripcion = await _context.Inscripciones
                .Include(i => i.Alumno)
                .Include(i => i.Materia)
                .FirstOrDefaultAsync(m => m.InscripcionId == id);

            if (inscripcion == null) return NotFound();

            return View(inscripcion);
        }



        //[Authorize(Roles = "Admin, Preceptor")]
        // POST: Inscripciones/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var inscripcion = await _context.Inscripciones.FindAsync(id);
            _context.Inscripciones.Remove(inscripcion);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }


        //[Authorize(Roles = "Admin, Preceptor")]
        private bool InscripcionExists(int id)
        {
            return _context.Inscripciones.Any(e => e.InscripcionId == id);
        }
    }
}
