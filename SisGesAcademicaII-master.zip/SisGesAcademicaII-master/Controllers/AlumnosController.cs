﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SisGesAcademica.Data;
using SisGesAcademica.Data.DTO;
using SisGesAcademica.Models;
using System.Security.Cryptography;
using System.Text;
using static SisGesAcademica.Models.Alumno;

namespace SisGesAcademica.Controllers
{
    //[Authorize(Roles = "Admin, Preceptor")]

    public class AlumnosController : Controller
    {
        private readonly SisGesAcademicaContext _context;

        public AlumnosController(SisGesAcademicaContext context)
        {
            _context = context;
        }

        // GET: Alumnos
        public async Task<IActionResult> Index()
        {
            var sisGesAcademicaContext = _context.Alumnos.Include(a => a.Ro);
            return View(await sisGesAcademicaContext.ToListAsync());
        }


        // GET: Alumnos/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var alumno = await _context.Alumnos
                .Include(a => a.Ro)
                .Include(a => a.Carrera)
                .FirstOrDefaultAsync(m => m.UsId == id);
            if (alumno == null)
            {
                return NotFound();
            }

            return View(alumno);
        }

        // GET: Alumnos/Create
        public IActionResult Create()
        {
            var rolAlumno = _context.Roles.FirstOrDefault(r => r.RoDenominacion == "Alumno");

            if (rolAlumno == null)
            {
                return NotFound("El rol 'Alumno' no está configurado en el sistema");
            }

            var usuariosAlumnos = _context.Usuarios
                .Where(u => u.RoId == rolAlumno.RoId && u.UsActivo == true)
                .OrderBy(u => u.UsApellido)
                .ThenBy(u => u.UsNombre)
                .Select(u => new
                {
                    u.UsId,
                    NombreCompleto = $"{u.UsApellido}, {u.UsNombre} - DNI: {u.UsDni}"
                })
                .ToList();

            ViewData["UsId"] = new SelectList(usuariosAlumnos, "UsId", "NombreCompleto");
            ViewBag.CaId = new SelectList(_context.Carreras, "CaId", "CaNombre");

            var model = new Alumno
            {
                AlIngreso = DateTime.Now.Year,
                AlEsAcademico = EstadoAcademico.Activo
            };

            return View(model);
        }

        // POST: Alumnos/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("UsId,AlLegajo,CaId,AlIngreso")] Alumno alumno)
        {
            var usuarioExistente = await _context.Usuarios
                .Include(u => u.Ro)
                .FirstOrDefaultAsync(u => u.UsId == alumno.UsId);

            if (usuarioExistente == null || usuarioExistente.Ro?.RoDenominacion != "Alumno")
            {
                ModelState.AddModelError("UsId", "Usuario no válido o no tiene rol Alumno");
                CargarListas();
                return View(alumno);
            }

            var alumnoExistente = await _context.Alumnos.FindAsync(alumno.UsId);
            if (alumnoExistente != null)
            {
                ModelState.AddModelError("", "Este usuario ya está registrado como alumno");
                CargarListas();
                return View(alumno);
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Usuarios.Remove(usuarioExistente);
                    await _context.SaveChangesAsync();

                    var nuevoAlumno = new Alumno
                    {
                        UsId = usuarioExistente.UsId,
                        UsDni = usuarioExistente.UsDni,
                        UsApellido = usuarioExistente.UsApellido,
                        UsNombre = usuarioExistente.UsNombre,
                        UsEmail = usuarioExistente.UsEmail,
                        UsTelefono = usuarioExistente.UsTelefono,
                        UsContrasena = usuarioExistente.UsContrasena,
                        RoId = usuarioExistente.RoId,
                        FechaCreacion = DateTime.Now,
                        FechaNacimiento = usuarioExistente.FechaNacimiento,
                        UsActivo = usuarioExistente.UsActivo,
                        UsGenero = usuarioExistente.UsGenero,
                        AlLegajo = GenerarLegajoAlumno(), // Sin parámetro
                        CaId = alumno.CaId,
                        AlIngreso = alumno.AlIngreso,
                        AlEsAcademico = EstadoAcademico.Activo,
          
                    };

                    _context.Alumnos.Add(nuevoAlumno);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = $"Alumno {nuevoAlumno.UsApellido}, {nuevoAlumno.UsNombre} creado exitosamente";
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateException ex)
                {
                    ModelState.AddModelError("", $"Error al guardar: {ex.InnerException?.Message}");
                    Console.WriteLine($"Error completo: {ex.ToString()}");
                }
            }

            CargarListas();
            return View(alumno);
        }

        private string GenerarLegajoAlumno()
        {
            int añoActual = DateTime.Now.Year;
            string nuevoLegajo;
            bool legajoExistente;
            int intentos = 0;
            const int maxIntentos = 5;

            do
            {
                var ultimoLegajo = _context.Alumnos
                    .Where(a => a.AlLegajo.StartsWith(añoActual.ToString()))
                    .OrderByDescending(a => a.AlLegajo)
                    .FirstOrDefault();

                int siguienteNumero = 1;
                if (ultimoLegajo != null)
                {
                    var partes = ultimoLegajo.AlLegajo.Split('-');
                    if (partes.Length == 2 && int.TryParse(partes[1], out int ultimoNumero))
                    {
                        siguienteNumero = ultimoNumero + 1;
                    }
                }

                nuevoLegajo = $"{añoActual}-{siguienteNumero:0000}";
                legajoExistente = _context.Alumnos.Any(a => a.AlLegajo == nuevoLegajo);
                intentos++;
            }
            while (legajoExistente && intentos < maxIntentos);

            if (legajoExistente)
            {
                throw new InvalidOperationException("No se pudo generar un legajo único después de varios intentos");
            }

            return nuevoLegajo;
        }

        private void CargarListas()
        {
            try
            {
                ViewBag.CaId = new SelectList(_context.Carreras, "CaId", "CaNombre");

                var rolAlumno = _context.Roles.FirstOrDefault(r => r.RoDenominacion == "Alumno");

                if (rolAlumno == null)
                {
                    ViewBag.ErrorRol = "No se encontró el rol 'Alumno' en el sistema";
                    ViewBag.UsId = new SelectList(Enumerable.Empty<SelectListItem>());
                    return;
                }

                var usuariosAlumnos = _context.Usuarios
                    .Where(u => u.RoId == rolAlumno.RoId && u.UsActivo == true)
                    .OrderBy(u => u.UsApellido)
                    .ThenBy(u => u.UsNombre)
                    .Select(u => new
                    {
                        u.UsId,
                        NombreCompleto = $"{u.UsApellido}, {u.UsNombre} - DNI: {u.UsDni}"
                    })
                    .ToList();

                Console.WriteLine($"Usuarios alumnos encontrados: {usuariosAlumnos.Count}");

                ViewBag.UsId = new SelectList(usuariosAlumnos, "UsId", "NombreCompleto");
            }
            catch (Exception ex)
            {
                ViewBag.ErrorCarga = $"Error al cargar listas: {ex.Message}";
            }
        }


        // GET: Alumnos/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var alumno = await _context.Alumnos.FindAsync(id);
            if (alumno == null)
            {
                return NotFound();
            }



            // Agregar la lista de estados académicos
            ViewData["AlEsAcademico"] = new SelectList(Enum.GetValues(typeof(EstadoAcademico)), alumno.AlEsAcademico);

            ViewData["RoId"] = new SelectList(_context.Roles, "RoId", "RoDenominacion", alumno.RoId);
            ViewData["CaId"] = new SelectList(_context.Carreras, "CaId", "CaNombre", alumno.CaId);
            ViewData["UsGenero"] = new SelectList(new List<string> { "Masculino", "Femenino" }, alumno.UsGenero);

            return View(alumno);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("AlLegajo,CaId,AlIngreso,AlEsAcademico,UsId,UsDni,UsApellido,UsNombre,UsEmail,UsTelefono,UsContrasena,RoId,FechaCreacion,FechaNacimiento,UsActivo,token_recovery,date_created,UsGenero")] Alumno alumno)
        {
            if (id != alumno.UsId)
            {
                return NotFound();
            }

            // Obtener el alumno existente
            var alumnoExistente = await _context.Alumnos.FindAsync(id);
            if (alumnoExistente == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Copiar solo los campos editables
                    alumnoExistente.UsApellido = alumno.UsApellido;
                    alumnoExistente.UsNombre = alumno.UsNombre;
                    alumnoExistente.UsDni = alumno.UsDni;
                    alumnoExistente.UsEmail = alumno.UsEmail;
                    alumnoExistente.UsTelefono = alumno.UsTelefono;
                    alumnoExistente.FechaNacimiento = alumno.FechaNacimiento;
                    alumnoExistente.UsGenero = alumno.UsGenero;
                    alumnoExistente.UsActivo = alumno.UsActivo;
                    alumnoExistente.AlLegajo = alumno.AlLegajo;
                    alumnoExistente.CaId = alumno.CaId;
                    alumnoExistente.AlIngreso = alumno.AlIngreso;
                    alumnoExistente.AlEsAcademico = alumno.AlEsAcademico;

                    // Manejo de contraseña: solo si se proporcionó una nueva
                    if (!string.IsNullOrEmpty(alumno.UsContrasena))
                    {
                        alumnoExistente.UsContrasena = GetMD5(alumno.UsContrasena);
                    }

                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = "Alumno actualizado correctamente";
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AlumnoExists(alumno.UsId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "Error al guardar: " + ex.Message);
                }
            }

            // Recargar datos necesarios para la vista
            ViewData["AlEsAcademico"] = new SelectList(Enum.GetValues(typeof(EstadoAcademico)), alumno.AlEsAcademico);
            ViewData["RoId"] = new SelectList(_context.Roles, "RoId", "RoDenominacion", alumno.RoId);
            ViewData["CaId"] = new SelectList(_context.Carreras, "CaId", "CaNombre", alumno.CaId);
            ViewData["UsGenero"] = new SelectList(new List<string> { "Masculino", "Femenino" }, alumno.UsGenero);

            return View(alumno);
        }

        // GET: Alumnos/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var alumno = await _context.Alumnos
                .Include(a => a.Ro)
                .Include(a => a.Carrera)
                .FirstOrDefaultAsync(m => m.UsId == id);
            if (alumno == null)
            {
                return NotFound();
            }

            return View(alumno);
        }

        // POST: Alumnos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var alumno = await _context.Alumnos.FindAsync(id);
            if (alumno != null)
            {
                _context.Alumnos.Remove(alumno);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AlumnoExists(int id)
        {
            return _context.Alumnos.Any(e => e.UsId == id);
        }

        private string GetMD5(string str)
        {
            MD5 md5 = MD5.Create();
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[]? stream = null;
            StringBuilder sb = new StringBuilder();
            stream = md5.ComputeHash(encoding.GetBytes(str));
            for (int i = 0; i < stream.Length; i++) sb.AppendFormat("{0:x2}", stream[i]);
            return sb.ToString();
        }


        [HttpPost]
        public async Task<IActionResult> RegisterInCareer(AlumnoCareerRegistration model)
        {
            // Obtener usuario existente
            var usuario = await _context.Usuarios.FindAsync(model.UsId);
            if (usuario == null) return NotFound();

            // Verificar si ya es alumno
            if (usuario is Alumno)
                return BadRequest("El usuario ya es alumno");

            // Obtener rol "Alumno"
            var rolAlumno = await _context.Roles.FirstOrDefaultAsync(r =>
                r.RoDenominacion == "Alumno");
            if (rolAlumno == null) return BadRequest("Rol Alumno no encontrado");

            // Crear entidad Alumno copiando propiedades
            var alumno = new Alumno();
            var properties = typeof(Usuario).GetProperties();
            foreach (var prop in properties)
            {
                if (prop.CanWrite)
                    prop.SetValue(alumno, prop.GetValue(usuario));
            }

            // Actualizar propiedades específicas
            alumno.RoId = rolAlumno.RoId;
            alumno.AlLegajo = model.AlLegajo;
            alumno.CaId = model.CaId;
            alumno.AlIngreso = model.AlIngreso;
            alumno.AlEsAcademico = Alumno.EstadoAcademico.Activo;

            // Actualizar en base de datos
            _context.Usuarios.Remove(usuario);
            _context.Usuarios.Add(alumno);
            await _context.SaveChangesAsync();

            return RedirectToAction("Details", new { id = alumno.UsId });
        }
    }
}
