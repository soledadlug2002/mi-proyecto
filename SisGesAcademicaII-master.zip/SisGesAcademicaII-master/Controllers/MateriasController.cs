﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SisGesAcademica.Data;
using SisGesAcademica.Models;

namespace SisGesAcademica.Controllers
{
    //[Authorize(Roles = "Admin, Preceptor")]
    public class MateriasController : Controller
    {
        private readonly SisGesAcademicaContext _context;

        public MateriasController(SisGesAcademicaContext context)
        {
            _context = context;
        }

        // GET: Materias
        public async Task<IActionResult> Index()
        {
            var sisGesAcademicaContext = _context.Materias.Include(m => m.Carrera).Include(m => m.Docente);
            return View(await sisGesAcademicaContext.ToListAsync());
        }

        // GET: Materias/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var materia = await _context.Materias
                .Include(m => m.Carrera)
                .Include(m => m.Docente)
                .FirstOrDefaultAsync(m => m.MaId == id);
            if (materia == null)
            {
                return NotFound();
            }

            return View(materia);
        }

        // GET: Materias/Create
        public IActionResult Create()
        {
            ViewData["CaId"] = new SelectList(_context.Carreras, "CaId", "CaNombre");
            ViewData["DoId"] = GetDocentesSelectList(); // Usar método común
            return View();
        }

        // POST: Materias/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("MaId,MaNombre,MaAnio,Cuatrimestre,DoId,MaCupoMaximo,CaId")] Materia materia)
        {
            if (ModelState.IsValid)
            {
                _context.Add(materia);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            // Reconstruir los SelectList correctamente
            ViewData["CaId"] = new SelectList(_context.Carreras, "CaId", "CaNombre", materia.CaId);
            ViewData["DoId"] = GetDocentesSelectList(materia.DoId); // Pasar el ID seleccionado

            return View(materia);
        }

        // Método auxiliar para obtener la lista de docentes formateada
        private SelectList GetDocentesSelectList(object selectedValue = null)
        {
            var docentes = _context.Docentes
                .Select(d => new
                {
                    UsId = d.UsId,
                    NombreCompleto = $"{d.UsNombre} {d.UsApellido} - DNI: {d.UsDni}"
                })
                .ToList();

            return new SelectList(docentes, "UsId", "NombreCompleto", selectedValue);
        }

        // GET: Materias/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var materia = await _context.Materias.FindAsync(id);
            if (materia == null)
            {
                return NotFound();
            }
            ViewData["CaId"] = new SelectList(_context.Carreras, "CaId", "CaNombre", materia.CaId);
            ViewData["DoId"] = new SelectList(_context.Docentes, "UsId", "Discriminator", materia.DoId);
            return View(materia);
        }

        // POST: Materias/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("MaId,MaNombre,MaAnio,Cuatrimestre,DoId,MaCupoMaximo,CaId")] Materia materia)
        {
            if (id != materia.MaId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(materia);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MateriaExists(materia.MaId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CaId"] = new SelectList(_context.Carreras, "CaId", "CaNombre", materia.CaId);
            ViewData["DoId"] = new SelectList(_context.Docentes, "UsId", "Discriminator", materia.DoId);
            return View(materia);
        }

        // GET: Materias/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var materia = await _context.Materias
                .Include(m => m.Carrera)
                .Include(m => m.Docente)
                .FirstOrDefaultAsync(m => m.MaId == id);
            if (materia == null)
            {
                return NotFound();
            }

            return View(materia);
        }

        // POST: Materias/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var materia = await _context.Materias.FindAsync(id);
            if (materia != null)
            {
                _context.Materias.Remove(materia);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MateriaExists(int id)
        {
            return _context.Materias.Any(e => e.MaId == id);
        }
    }
}
