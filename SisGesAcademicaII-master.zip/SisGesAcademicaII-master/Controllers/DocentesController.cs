﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SisGesAcademica.Data;
using SisGesAcademica.Models;
using System.Security.Cryptography;
using System.Text;

namespace SisGesAcademica.Controllers
{
    //[Authorize(Roles = "Admin, Preceptor")]
    public class DocentesController : Controller
    {
        private readonly SisGesAcademicaContext _context;

        public DocentesController(SisGesAcademicaContext context)
        {
            _context = context;
        }



        // GET: Docentes
        public async Task<IActionResult> Index()
        {
            var sisGesAcademicaContext = _context.Docentes.Include(d => d.Ro);
            return View(await sisGesAcademicaContext.ToListAsync());
        }


        // GET: Docentes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var docente = await _context.Docentes
                .Include(d => d.Ro)
                .FirstOrDefaultAsync(m => m.UsId == id);
            if (docente == null)
            {
                return NotFound();
            }

            return View(docente);
        }


        // GET: Docentes/Create
        public IActionResult Create()
        {
            // Obtener el ID del rol Docente
            var rolDocente = _context.Roles.FirstOrDefault(r => r.RoDenominacion == "Docente");

            if (rolDocente == null)
            {
                // Manejar el caso si no existe el rol Docente
                return NotFound("El rol 'Docente' no está configurado en el sistema");
            }

            // Obtener usuarios con rol Docente
            var usuariosDocentes = _context.Usuarios
                .Where(u => u.RoId == rolDocente.RoId)
                .Select(u => new
                {
                    u.UsId,
                    NombreCompleto = $"{u.UsApellido}, {u.UsNombre} - DNI: {u.UsDni}"
                })
                .ToList();

            ViewData["UsId"] = new SelectList(usuariosDocentes, "UsId", "NombreCompleto");
            ViewData["RoId"] = new SelectList(_context.Roles, "RoId", "RoDenominacion");
            ViewData["UsGenero"] = new SelectList(new List<string> { "Masculino", "Femenino" });



            return View();
        }


  
        // Controllers/DocentesController.cs

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DoLegajo,DoTitulo,DoEspecialidad,UsId")] Docente docente)
        {
            var usuarioExistente = await _context.Usuarios
                .Include(u => u.Ro)
                .FirstOrDefaultAsync(u => u.UsId == docente.UsId);

            if (usuarioExistente == null || usuarioExistente.Ro?.RoDenominacion != "Docente")
            {
                ModelState.AddModelError("UsId", "El usuario seleccionado no es válido o no tiene rol Docente");
                await CargarUsuariosDocentes();
                return View(docente);
            }

            var docenteExistente = await _context.Docentes.FindAsync(docente.UsId);
            if (docenteExistente != null)
            {
                ModelState.AddModelError("", "Este usuario ya está registrado como docente");
                await CargarUsuariosDocentes();
                return View(docente);
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Eliminar Usuario anterior
                    _context.Usuarios.Remove(usuarioExistente);
                    await _context.SaveChangesAsync();

                    // Crear nuevo Docente con datos del Usuario

                    docente.UsDni = usuarioExistente.UsDni;
                    docente.UsApellido = usuarioExistente.UsApellido;
                    docente.UsNombre = usuarioExistente.UsNombre;
                    docente.UsEmail = usuarioExistente.UsEmail;
                    docente.UsTelefono = usuarioExistente.UsTelefono;
                    docente.UsContrasena = usuarioExistente.UsContrasena;
                    docente.RoId = usuarioExistente.RoId;
                    docente.FechaCreacion = DateTime.Now;
                    docente.FechaNacimiento = usuarioExistente.FechaNacimiento;
                    docente.UsActivo = true;
                    docente.UsGenero = usuarioExistente.UsGenero;
                    docente.DoLegajo = GenerarLegajoDocente();


                    _context.Docentes.Add(docente);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = $"Docente {docente.UsApellido}, {docente.UsNombre} creado exitosamente";
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateException ex)
                {
                    ModelState.AddModelError("", $"Error al guardar: {ex.InnerException?.Message}");
                    Console.WriteLine($"Error completo: {ex.ToString()}");
                }
            }

            await CargarUsuariosDocentes();
            return View(docente);
        }


        private string GenerarLegajoDocente()
        {
            int añoActual = DateTime.Now.Year;
            string nuevoLegajo;
            bool legajoExistente;
            int intentos = 0;
            const int maxIntentos = 5;

            do
            {
                var ultimoLegajo = _context.Docentes
                    .Where(a => a.DoLegajo.StartsWith(añoActual.ToString()))
                    .OrderByDescending(a => a.DoLegajo)
                    .FirstOrDefault();

                int siguienteNumero = 1;
                if (ultimoLegajo != null)
                {
                    var partes = ultimoLegajo.DoLegajo.Split('-');
                    if (partes.Length == 2 && int.TryParse(partes[1], out int ultimoNumero))
                    {
                        siguienteNumero = ultimoNumero + 1;
                    }
                }

                nuevoLegajo = $"{añoActual}-{siguienteNumero:0000}";
                legajoExistente = _context.Docentes.Any(a => a.DoLegajo == nuevoLegajo);
                intentos++;
            }
            while (legajoExistente && intentos < maxIntentos);

            if (legajoExistente)
            {
                throw new InvalidOperationException("No se pudo generar un legajo único después de varios intentos");
            }

            return nuevoLegajo;
        }


        private async Task CargarUsuariosDocentes()
        {
            var usuariosDocentes = await _context.Usuarios
                .Where(u => u.Ro.RoDenominacion == "Docente") // Filtra directamente por nombre de rol
                .Select(u => new
                {
                    u.UsId,
                    NombreCompleto = $"{u.UsApellido}, {u.UsNombre} - DNI: {u.UsDni}"
                })
                .ToListAsync();

            ViewData["UsId"] = new SelectList(usuariosDocentes, "UsId", "NombreCompleto");
        }




  
        // GET: Docentes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var docente = await _context.Docentes.FindAsync(id);
            if (docente == null)
            {
                return NotFound();
            }

            //// Guardar la contraseña actual en ViewData para usarla en la vista
            //ViewData["CurrentPassword"] = docente.UsContrasena;

            ViewData["RoId"] = new SelectList(_context.Roles, "RoId", "RoDenominacion", docente.RoId);
            ViewData["UsGenero"] = new SelectList(new List<string> { "Masculino", "Femenino" });
            return View(docente);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("DoLegajo,DoTitulo,DoEspecialidad,UsId,UsDni,UsApellido,UsNombre,UsEmail,UsTelefono,UsContrasena,RoId,FechaCreacion,FechaNacimiento,UsActivo,token_recovery,date_created,UsGenero")] Docente docente)
        {
            if (id != docente.UsId)
            {
                return NotFound();
            }

            //var docenteExistente = await _context.Docentes.FindAsync(id);
            //if (docenteExistente == null)
            //{
            //    return NotFound();
            //}

            if (ModelState.IsValid)
            {
                // Encriptar contraseña
                docente.UsContrasena = GetMD5(docente.UsContrasena);


                try
                {

                    _context.Update(docente);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DocenteExists(docente.UsId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            ViewData["RoId"] = new SelectList(_context.Roles, "RoId", "RoDenominacion", docente.RoId);
            ViewData["UsGenero"] = new SelectList(new List<string> { "Masculino", "Femenino" }, docente.UsGenero);
            return View(docente);
        }




        // GET: Docentes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var docente = await _context.Docentes
                .Include(d => d.Ro)
                .FirstOrDefaultAsync(m => m.UsId == id);
            if (docente == null)
            {
                return NotFound();
            }

            return View(docente);
        }



        // POST: Docentes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var docente = await _context.Docentes.FindAsync(id);
            if (docente != null)
            {
                _context.Docentes.Remove(docente);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }



        private bool DocenteExists(int id)
        {
            return _context.Docentes.Any(e => e.UsId == id);
        }


        private string GetMD5(string str)
        {
            MD5 md5 = MD5.Create();
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[]? stream = null;
            StringBuilder sb = new StringBuilder();
            stream = md5.ComputeHash(encoding.GetBytes(str));
            for (int i = 0; i < stream.Length; i++) sb.AppendFormat("{0:x2}", stream[i]);
            return sb.ToString();
        }
    }
}
