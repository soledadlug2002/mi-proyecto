﻿using System.ComponentModel.DataAnnotations;

namespace SisGesAcademica.Data.DTO
{
    public class AlumnoCareerRegistration
    {
        [Required]
        public int UsId { get; set; }

        [Required]
        [StringLength(20)]
        public string AlLegajo { get; set; }

        [Required]
        public int CaId { get; set; }

        [Required]
        [Range(2000, 2100)]
        public int AlIngreso { get; set; }
    }
}
