﻿using System.ComponentModel.DataAnnotations;

namespace SisGesAcademica.Data.DTO
{
    public class UsuarioDTO
    {
        [Key]
        [Display(Name = "ID Usuario")]
        public int UsId { get; set; }

        [Display(Name = "DNI")]
        [Required(ErrorMessage = "El DNI es obligatorio")]
        [RegularExpression(@"^[1-9][0-9]{6,7}$", ErrorMessage = "DNI inválido (7-8 dígitos sin puntos)")]
        [Range(1000000, 99999999, ErrorMessage = "Rango: 1.000.000 a 99.999.999")]
        public long UsDni { get; set; }

        [Display(Name = "Nombres")]
        [Required(ErrorMessage = "Nombre obligatorio")]
        [RegularExpression(@"^[\p{L}\s']+$", ErrorMessage = "Solo letras, espacios y apóstrofes")]
        [MaxLength(50, ErrorMessage = "Máximo 50 caracteres")]
        public string UsNombre { get; set; } = null!;

        [Display(Name = "Apellido")]
        [Required(ErrorMessage = "Apellido obligatorio")]
        [RegularExpression(@"^[\p{L}\s']+$", ErrorMessage = "Solo letras, espacios y apóstrofes")]
        [MaxLength(50, ErrorMessage = "Máximo 50 caracteres")]
        public string UsApellido { get; set; } = null!;

        [Display(Name = "Teléfono")]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "10 dígitos sin espacios (ej: 3511234567)")]
        public long? UsTelefono { get; set; }

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Email obligatorio")]
        [EmailAddress(ErrorMessage = "Formato inválido")]
        [MaxLength(100, ErrorMessage = "Máximo 100 caracteres")]
        public string UsEmail { get; set; } = null!;

        [Display(Name = "Contraseña")]
        [DataType(DataType.Password)]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,50}$",
            ErrorMessage = "Debe incluir mayúscula, minúscula, número y símbolo")]
        [MinLength(8, ErrorMessage = "Mínimo 8 caracteres")]
        [MaxLength(50, ErrorMessage = "Máximo 50 caracteres")]
        public string? UsContrasena { get; set; }

        [Display(Name = "Confirmar Contraseña")]
        [DataType(DataType.Password)]
        [Compare("UsContrasena", ErrorMessage = "Las contraseñas no coinciden")]
        public string? ConfirmarContrasena { get; set; }

        [Display(Name = "Género")]
        [Required(ErrorMessage = "Seleccione género")]
        public Genero UsGenero { get; set; }

        [Display(Name = "Rol")]
        [Required(ErrorMessage = "Seleccione rol")]
        public string rol { get; set; } = null!; // Cambiado a string para mostrar el nombre del rol

        [Display(Name = "Fecha Nacimiento")]
        [Required(ErrorMessage = "Fecha obligatoria")]
        [DataType(DataType.Date)]
        [AgeValidation(MinAge = 16, MaxAge = 100, ErrorMessage = "Edad debe ser entre 16 y 100 años")]
        public DateTime FechaNacimiento { get; set; } = DateTime.Now.AddYears(-18);

        // Propiedad para autenticación
        [Display(AutoGenerateField = false)]
        public bool Autenticado { get; set; } = false;
    }

    public enum Genero
    {
        [Display(Name = "Masculino")]
        Masculino,

        [Display(Name = "Femenino")]
        Femenino,

        [Display(Name = "Prefiero no decir")]
        Otro
    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public sealed class AgeValidationAttribute : ValidationAttribute
    {
        public int MinAge { get; set; }
        public int MaxAge { get; set; }

        public override bool IsValid(object? value)
        {
            if (value is DateTime fechaNacimiento)
            {
                var hoy = DateTime.Today;
                var edad = hoy.Year - fechaNacimiento.Year;

                if (fechaNacimiento.Date > hoy.AddYears(-edad))
                    edad--;

                return edad >= MinAge && edad <= MaxAge;
            }
            return false;
        }
    }
}