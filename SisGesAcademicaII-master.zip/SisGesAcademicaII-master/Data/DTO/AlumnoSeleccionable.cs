﻿namespace SisGesAcademica.Data.DTO
{
    public class AlumnoSeleccionable
    {
        public int UsId { get; set; }
        public string Legajo { get; set; } = null!;
        public string NombreCompleto { get; set; } = null!;
    }
}
