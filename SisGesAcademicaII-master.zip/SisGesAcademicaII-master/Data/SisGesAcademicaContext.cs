﻿using Microsoft.EntityFrameworkCore;
using SisGesAcademica.Models;

namespace SisGesAcademica.Data
{
    public class SisGesAcademicaContext : DbContext
    {
        public SisGesAcademicaContext(DbContextOptions<SisGesAcademicaContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<Usuario> Usuarios { get; set; }
        public virtual DbSet<Alumno> Alumnos { get; set; }
        public virtual DbSet<Docente> Docentes { get; set; }
        public virtual DbSet<Materia> Materias { get; set; }
        public virtual DbSet<Carrera> Carreras { get; set; }
        public virtual DbSet<Inscripcion> Inscripciones { get; set; }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    base.OnModelCreating(modelBuilder);

        //    // Configuración de relaciones con restricciones de eliminación

        //    // 1. Relación Usuario-Rol
        //    modelBuilder.Entity<Usuario>()
        //        .HasOne(u => u.Ro)
        //        .WithMany(r => r.Usuarios)
        //        .HasForeignKey(u => u.RoId)
        //        .OnDelete(DeleteBehavior.Restrict); // Evita eliminar rol si hay usuarios asociados

        //    // 2. Relación Alumno-Carrera
        //    modelBuilder.Entity<Alumno>()
        //        .HasOne(a => a.Carrera)
        //        .WithMany(c => c.Alumnos)
        //        .HasForeignKey(a => a.CaId)
        //        .OnDelete(DeleteBehavior.Restrict); // Evita eliminar carrera si hay alumnos

        //    // 3. Relación Materia-Carrera
        //    modelBuilder.Entity<Materia>()
        //        .HasOne(m => m.Carrera)
        //        .WithMany(c => c.Materias)
        //        .HasForeignKey(m => m.CaId)
        //        .OnDelete(DeleteBehavior.Restrict); // Evita eliminar carrera si hay materias

        //    // 4. Relación Materia-Docente
        //    modelBuilder.Entity<Materia>()
        //        .HasOne(m => m.Docente)
        //        .WithMany(d => d.Materias)
        //        .HasForeignKey(m => m.DoId)
        //        .OnDelete(DeleteBehavior.SetNull); // Al eliminar docente, materia queda sin docente

        //    // 5. Relación Inscripción-Alumno
        //    modelBuilder.Entity<Inscripcion>()
        //        .HasOne(i => i.Alumno)
        //        .WithMany(a => a.Inscripciones)
        //        .HasForeignKey(i => i.AlId)
        //        .OnDelete(DeleteBehavior.Restrict); // Evita eliminar alumno si tiene inscripciones

        //    // 6. Relación Inscripción-Materia
        //    modelBuilder.Entity<Inscripcion>()
        //        .HasOne(i => i.Materia)
        //        .WithMany(m => m.Inscripciones)
        //        .HasForeignKey(i => i.MaId)
        //        .OnDelete(DeleteBehavior.Restrict); // Evita eliminar materia si tiene inscripciones

        //    modelBuilder.Entity<Usuario>()
        //        .ToTable("Usuarios")
        //        .HasDiscriminator<string>("Discriminator")
        //        .HasValue<Usuario>("Usuario")
        //        .HasValue<Alumno>("Alumno")
        //        .HasValue<Docente>("Docente");

        //    // Configura las propiedades específicas de Docente
        //    modelBuilder.Entity<Docente>(entity =>
        //    {
        //        entity.Property(d => d.DoLegajo).HasColumnName("DoLegajo");
        //        entity.Property(d => d.DoTitulo).HasColumnName("DoTitulo");
        //        entity.Property(d => d.DoEspecialidad).HasColumnName("DoEspecialidad");
        //    });

        //    modelBuilder.Entity<Alumno>(entity =>
        //    {
        //        entity.Property(a => a.AlLegajo).HasColumnName("AlLegajo");
        //        entity.Property(a => a.AlIngreso).HasColumnName("AlIngreso");
        //        entity.Property(a => a.AlEsAcademico).HasColumnName("AlEsAcademico");
        //        entity.Property(a => a.CaId).HasColumnName("CaId");

        //        entity.HasOne(a => a.Carrera)
        //            .WithMany(c => c.Alumnos)
        //            .HasForeignKey(a => a.CaId)
        //            .OnDelete(DeleteBehavior.Restrict);
        //    });

        //    modelBuilder.Entity<Docente>(entity =>
        //    {
        //        entity.Property(d => d.DoLegajo).HasColumnName("DoLegajo");
        //        entity.Property(d => d.DoTitulo).HasColumnName("DoTitulo");
        //        entity.Property(d => d.DoEspecialidad).HasColumnName("DoEspecialidad");
        //    });


        //    modelBuilder.Entity<Carrera>()
        //        .HasIndex(c => c.CaNombre)
        //        .IsUnique()
        //        .HasName("IX_Carreras_CaNombre");

        //    modelBuilder.Entity<Carrera>()
        //        .HasIndex(c => c.CaTitOtorgado)
        //        .IsUnique()
        //        .HasName("IX_Carreras_CaTitOtorgado");

        //}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configuración de la herencia primero
            modelBuilder.Entity<Usuario>()
                .ToTable("Usuarios")
                .HasDiscriminator<string>("Discriminator")
                .HasValue<Usuario>("Usuario")
                .HasValue<Alumno>("Alumno")
                .HasValue<Docente>("Docente");

            // Configuración específica de Alumno
            modelBuilder.Entity<Alumno>(entity =>
            {
                entity.Property(a => a.AlLegajo).HasColumnName("AlLegajo");
                entity.Property(a => a.AlIngreso).HasColumnName("AlIngreso");
                entity.Property(a => a.AlEsAcademico).HasColumnName("AlEsAcademico");
                entity.Property(a => a.CaId).HasColumnName("CaId");

                entity.HasOne(a => a.Carrera)
                    .WithMany(c => c.Alumnos)
                    .HasForeignKey(a => a.CaId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // Configuración específica de Docente
            modelBuilder.Entity<Docente>(entity =>
            {
                entity.Property(d => d.DoLegajo).HasColumnName("DoLegajo");
                entity.Property(d => d.DoTitulo).HasColumnName("DoTitulo");
                entity.Property(d => d.DoEspecialidad).HasColumnName("DoEspecialidad");
            });

            // Otras relaciones (sin duplicar las ya configuradas arriba)
            modelBuilder.Entity<Usuario>()
                .HasOne(u => u.Ro)
                .WithMany(r => r.Usuarios)
                .HasForeignKey(u => u.RoId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Materia>()
                .HasOne(m => m.Carrera)
                .WithMany(c => c.Materias)
                .HasForeignKey(m => m.CaId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Materia>()
                .HasOne(m => m.Docente)
                .WithMany(d => d.Materias)
                .HasForeignKey(m => m.DoId)
                .OnDelete(DeleteBehavior.SetNull);

            //modelBuilder.Entity<Inscripcion>()
            //    .HasOne(i => i.Alumno)
            //    .WithMany(a => a.Inscripciones)
            //    .HasForeignKey(i => i.AlId)
            //    .OnDelete(DeleteBehavior.Restrict);

            //modelBuilder.Entity<Inscripcion>()
            //    .HasOne(i => i.Materia)
            //    .WithMany(m => m.Inscripciones)
            //    .HasForeignKey(i => i.MaId)
            //    .OnDelete(DeleteBehavior.Restrict);

            // Configurar relación Inscripción-Alumno
            modelBuilder.Entity<Inscripcion>()
                .HasOne(i => i.Alumno)
                .WithMany(a => a.Inscripciones)
                .HasForeignKey(i => i.AlId)
                .HasConstraintName("FK_Inscripciones_Alumnos");

            // Configurar relación Inscripción-Materia
            modelBuilder.Entity<Inscripcion>()
                .HasOne(i => i.Materia)
                .WithMany(m => m.Inscripciones)
                .HasForeignKey(i => i.MaId)
                .HasConstraintName("FK_Inscripciones_Materias");

            // Índices únicos
            modelBuilder.Entity<Carrera>()
                .HasIndex(c => c.CaNombre)
                .IsUnique();

            modelBuilder.Entity<Carrera>()
                .HasIndex(c => c.CaTitOtorgado)
                .IsUnique();
        }
    }
}